import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.LowerCaseFilter;
import org.apache.lucene.analysis.StopFilter;
import org.apache.lucene.analysis.en.PorterStemFilter;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;

public class CustomAnalyzer extends Analyzer {

    @Override
    protected TokenStreamComponents createComponents(String fieldName) {
    	
    	// TODO: Try to implement the createComponents method in such a way that:
    	// - all letters have been changed to lowercase
    	// - filter out english stop words
    	// - use Porter Stemmer
    	// hint: LowerCaseFilter, StopFilter, EnglishAnalyzer, PorterStemFilter
    	// Run the code and check if everything works properly with the sample text (you can also test it on your own sample text)
    	
		// TODOo-done
		final StandardTokenizer src = new StandardTokenizer();
		return new TokenStreamComponents(src, new PorterStemFilter(new StopFilter(new LowerCaseFilter(src),
				EnglishAnalyzer.getDefaultStopSet())));
        
    	// TODO: If you have completed the above task and have a properly functioning CustomAnalyzer
    	// - Replace StandardAnalyzer with CustomAnalyzer in Indexer.java and SearchEngine.java
    	// - Run Indexer.java
    	// - Run SearchEngine and check if the query problems were resolved
    }
    
    public static List<String> analyze(String text, Analyzer analyzer) throws IOException{
    	String FIELD_NAME = "field_name";
        List<String> result = new ArrayList<String>();
        TokenStream tokenStream = analyzer.tokenStream(FIELD_NAME, text);
        CharTermAttribute attr = tokenStream.addAttribute(CharTermAttribute.class);
        tokenStream.reset();
        while(tokenStream.incrementToken()) {
           result.add(attr.toString());
        }       
        return result;
    }
    
    public static void main(String args[]) {
    	// This method allows you to see how a given Analyzer works on a specific text
    	
    	String SAMPLE_TEXT = "Some StopWords Stop words he she it is the are am you "
    			+ "This is, Sample (text) With123 456nUmBeRs "
    			+ "And & comas,,, dots... <br> (ac) {ke} [ts] "
    			+ "^ email: user@example.com OR URL - https://www.google.com/ also "
    			+ "PAsT SImpLE teNse: "
    			+ "be was were been "
    			+ "drink drank drunk "
    			+ "plural: bananas oranges strawberries "
    			+ "hex resource color "
    			+ "hexes resources colors";
    	try {
    		
    		System.out.println("STANDARD ANALYZER:");
			List<String> result = analyze(SAMPLE_TEXT, new StandardAnalyzer());
			System.out.println(result);
			
			System.out.println();
			
			System.out.println("CUSTOM ANALYZER:");
			result = analyze(SAMPLE_TEXT, new CustomAnalyzer());
			System.out.println(result);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
}