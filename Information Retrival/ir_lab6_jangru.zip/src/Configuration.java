public class Configuration {
    public static final String data_dir = "data";
    public static final String index_dir = "index";
    public static final String id = "id";
    public static final String filename = "filename";
    public static final String content = "content";
    public static final String links = "links";
    public static final String title = "title";
    public static final String url = "url";
    public static final int default_no_of_docs = 10;
}
