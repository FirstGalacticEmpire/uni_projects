import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

import org.apache.lucene.document.Field;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class Indexer {

    private IndexWriter createIndexWriter() {
        // TODO: Create StandardAnalyzer
        // TODOo-done
        CustomAnalyzer analyzer = new CustomAnalyzer();


        // TODO: Create IndexWriterConfig
        // TODOo-done
        // - check what parameter the constructor needs
        // - set it to open mode so that each run will re-index from scratch
        // hint: setOpenMode
        IndexWriterConfig indexWriterConfig = new IndexWriterConfig(analyzer);
        indexWriterConfig.setOpenMode(IndexWriterConfig.OpenMode.CREATE);


        // TODO: Create IndexWriter
        // TODOo-done
        // - use FSDirectory in order to open Path provided in the Configuration class
        // - apply try-catch if needed; on failure, return null
        // hint: FSDirectory.open, Paths.get
        try {
            Directory directory = FSDirectory.open(Paths.get(Configuration.index_dir));
            return new IndexWriter(directory, indexWriterConfig);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;

    }

    private ArrayList<Document> getDocuments() {
        // Read list of documents
        File dir = new File(Configuration.data_dir + "/" + Configuration.title);
        File[] files = dir.listFiles();
        if (files != null) {
            ArrayList<Document> documents = new ArrayList<>(files.length);
            for (int id = 0; id < files.length; id++) {
                System.out.println("Loading " + files[id].getName());

                // TODO: Load Document and add to the ArrayList
                // TODOo-done
                documents.add(loadDocument(files[id].getName(),id));
            }
            return documents;
        }
        return null;
    }

    private Document loadDocument(String filename, int id) {
        Document document = new Document();

        // The document that consists of key-value pairs must be defined.
        // In addition, for each key, two important issues must also be established:
        // - Should the value be indexed? - if not, it is still possible to store this information, but it will not be used during the search.
        // - Should the value be stored? - if not, it can be used to build an index, but cannot be referenced directly.

        // Possible classes to use: https://lucene.apache.org/core/8_0_0/core/org/apache/lucene/document/Field.html
        // hint: for texts that should be indexed it is usually best to use TextField and specify
        // Field.Store.YES or .NO depending on whether we want to store this information in the index

        // Texts that shouldn't be indexed, usually are stored - in this case it is best to use the StoredField class


        // TODO: write the following values to the document:

        // - DONE: id (stored, not indexed)
        document.add(new StoredField(Configuration.id, id));

        // - DONE: title (stored, indexed)
        document.add(new TextField(Configuration.title, readFile(Configuration.data_dir + "/" + Configuration.title + "/" + filename), Field.Store.YES));

        // - TODO: content (not stored, indexed)
        // TODOo-done
        document.add(new TextField(Configuration.content, readFile(Configuration.data_dir + "/" +Configuration.content + "/" + filename), Field.Store.NO));

        // - TODO: links (stored, not indexed)
        // TODOo-done
        document.add(new StoredField(Configuration.links, readFile(Configuration.data_dir + "/" + Configuration.links + "/" + filename)));

        // - TODO: url (stored, not indexed)
        // TODOo-done
        document.add(new StoredField(Configuration.url, readFile(Configuration.data_dir + "/" + Configuration.url + "/" + filename)));

        return document;
    }

    private String readFile(String filePath) {
        // Read the file and return the content of the file
        String content = "";

        try {
            content = new String(Files.readAllBytes(Paths.get(filePath)));
        } catch (IOException e) {
            e.printStackTrace();
        }

        return content;
    }

    private void indexDocuments() {
        // Get Documents collection
        ArrayList<Document> documents = getDocuments();

        // Create IndexWriter and create Index
        try {
            IndexWriter writer = createIndexWriter();
//            assert writer != null;
            writer.addDocuments(documents);
            writer.commit();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) {
        // TODO: if you have completed all previous TODOs in this file, run the main() function
        Indexer indexer = new Indexer();
        indexer.indexDocuments();
        System.out.println("Index created successfully");
    }

}
