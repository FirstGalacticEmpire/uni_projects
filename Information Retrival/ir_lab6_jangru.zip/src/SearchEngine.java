import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.core.SimpleAnalyzer;
import org.apache.lucene.analysis.standard.ClassicAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class SearchEngine {

    public static IndexReader loadIndexer() {
        try {
            Directory directory = FSDirectory.open(Paths.get(Configuration.index_dir));
            return DirectoryReader.open(directory);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static void printSearchResults(TopDocs topDocs, IndexSearcher indexSearcher) {
        for (ScoreDoc scoreDoc : topDocs.scoreDocs) {
            // TODO: print the results in form:
            // TODOo-done
            // <Title> (<URL>): Score
            // hint: IndexSearcher.doc, Document.get, ScoreDoc.doc, ScoreDoc.score
            try {
                Document doc = indexSearcher.doc(scoreDoc.doc);
                System.out.println(doc.get(Configuration.title) + " (" + doc.get(Configuration.url) + "): " +
                        scoreDoc.score);
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
    }

    private static void TODO1(Analyzer analyzer){
        // Load the previously generated index
        IndexReader reader = loadIndexer();

        // Define IndexSearcher
        IndexSearcher indexSearcher = new IndexSearcher(reader);

        // TODO1:
        try {
            QueryParser queryParser = new QueryParser(Configuration.content, analyzer);
            ArrayList<Query> listQueries = new ArrayList<>();

            listQueries.add(queryParser.parse("Hex")); // Similar results, different order but the further we
            // go the results differ more.
            listQueries.add(queryParser.parse("Hexes")); //Empty result, wikipedia search returns results
            // similar to Hex query on wikipedia

            listQueries.add(queryParser.parse("Rival")); // Similar results, different order
            listQueries.add(queryParser.parse("Rivals")); //Empty result, wikipedia search returns results similar
            // to rival query on wikipedia

            listQueries.add(queryParser.parse("resource")); //Empty result, wikipedia search returns results
            listQueries.add(queryParser.parse("resources")); //Empty Result, wikipedia search returns results
            // similar to resource request

            listQueries.add(queryParser.parse("Ocean")); // Similar results, different order
            listQueries.add(queryParser.parse("Oceans")); //Empty Result, wikipedia search returns results very similar
            // to Ocean query (to wikipedia)

            for (Query query : listQueries) {
                System.out.println("Query: " + query.toString());
                TopDocs topDocs = indexSearcher.search(query, 10);
                printSearchResults(topDocs, indexSearcher);
                System.out.println();
            }


        } catch (Exception e1) {
            e1.printStackTrace();
        }

        System.out.println("All queries processed, main() function finished");
    }

    private static void TODO2(Analyzer analyzer){
        // Load the previously generated index
        IndexReader reader = loadIndexer();

        // Define IndexSearcher
        IndexSearcher indexSearcher = new IndexSearcher(reader);

        // TODO2:
        try {
            QueryParser queryParser = new QueryParser(Configuration.content, analyzer);
            ArrayList<Query> listQueries = new ArrayList<>();

            listQueries.add(queryParser.parse("\"For generations, the people of Catan have lived in an island paradise\""));

            listQueries.add(queryParser.parse("Lumber AND Wool AND Grain AND Brick AND Ore AND Gold"));

            listQueries.add(queryParser.parse("ship^9 lumber"));

            listQueries.add(queryParser.parse("\"lumber settlement\"~3"));

            // Simple solution
            listQueries.add(queryParser.parse("pasture pasteur"));

            // Also I think this result is similar
            listQueries.add(queryParser.parse("pasture~"));


            for (Query query : listQueries) {
                System.out.println("Query: " + query.toString());
                TopDocs topDocs = indexSearcher.search(query, 10);
                printSearchResults(topDocs, indexSearcher);
                System.out.println();
            }

        } catch (Exception e1) {
            e1.printStackTrace();
        }

        System.out.println("All queries processed, main() function finished");
    }

    public static void main(String args[]) {
        // TODO: Check out some index queries by running the code
        // TODOo-done
        // Verify the results with: https://catan.fandom.com/wiki/Special:Search
        // You can also check the results by changing the search field to title
        // Proposed phrases:
        // - Ocean
        // - Hex
        // - Hexes
        // - Resource
        // - Resources
        // - Rival
        // - Rivals
        // Do you think the differences in results for singular and plural are okay?
        // How to fix that? See CustomAnalyzer.java class and solve TODOs

        // Results of queries are described in comment corresponding to queries in the function implemented above.
        TODO1(new StandardAnalyzer());
        // The differences are not okay, using CustomAnalyzer class solves the problem.
        TODO1(new CustomAnalyzer());


        // TODO: The last task(s)
        // For each of the tasks, save the query and show the results (save or copy the stdout from the code execution to the text file)
        // The implementation should allow all 5 queries to be run sequentially with main() execution.

        // Implement the code that answers the following queries (choose the proper query formulation):
        // TODOo-done
        // 1) TODO: Documents with such fragment - "For generations, the people of Catan have lived in an island paradise"
        // 2) TODO: Documents, where all resources are present simultaneously: Lumber, Wool, Grain, Brick, Ore, Gold
        // 3) TODO: Documents where "ship" or "road" but results with "ship" should appear at the top of the list
        // 4) TODO: Documents with two terms - "lumber" and "settlement" with the proximity distance = 3
        // 5) TODO: Documents that contains "pasture" or the misspelled word "pasteur"
        // hint: https://lucene.apache.org/core/8_0_0/queryparser/org/apache/lucene/queryparser/classic/package-summary.html
        TODO2(new CustomAnalyzer());

    }
}
